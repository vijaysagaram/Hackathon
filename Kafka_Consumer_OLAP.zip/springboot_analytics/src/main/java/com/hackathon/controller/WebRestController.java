package com.hackathon.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hackathon.analytics.DBConnection;
import com.hackathon.analytics.MainAnalytics;
import com.hackathon.storage.MainAnalyticsEntity;
import com.hackathon.storage.MessageEntity;

@RestController
@RequestMapping(value="/analytics")
public class WebRestController {

	@Autowired
	private MainAnalytics mainAnalytics;

	@Autowired
	private DBConnection dbConn;

	@GetMapping(value = "/execute")
	public String executeMainAnalytics() {
		try {
			ArrayList<MessageEntity> list = dbConn.getMessageEntity();
			ArrayList<MessageEntity> processedList = new ArrayList<MessageEntity>();
			for(MessageEntity messageEntity:list){
				if("NP".equalsIgnoreCase((messageEntity.getRealTimeOlap()))){
					messageEntity.setRealTimeOlap("OLAP");
					processedList.add(messageEntity);
				}
			}
			ArrayList<MainAnalyticsEntity> mainAnalyticsEntityList = mainAnalytics
					.performAnalytics(processedList);
			dbConn.saveMainAnalyticsEntity(mainAnalyticsEntityList,processedList);
			return "performAnalytics saved Successfully";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "issue in performanalytics";
	}

}
