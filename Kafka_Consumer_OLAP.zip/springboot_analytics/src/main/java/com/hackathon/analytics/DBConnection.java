/***************************************************
 Copyright 2017 CG, All rights reserved.
 ***************************************************/

package com.hackathon.analytics;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hackathon.storage.MainAnalyticsEntity;
import com.hackathon.storage.MainAnalyticsEntityRepository;
import com.hackathon.storage.MessageEntity;
import com.hackathon.storage.MessageRepository;

/**
 * retrieves and saves data from/to database
 * 
 * @author Vijay Sagaram
 *
 */
@Component
public class DBConnection {

	@Autowired
	private MessageRepository messageRepository;

	@Autowired
	private MainAnalyticsEntityRepository mainAnalyticsEntityRepository;

	public void saveMainAnalyticsEntity(ArrayList<MainAnalyticsEntity> mainAnalyticsEntityList, ArrayList<MessageEntity> processedList) {

		mainAnalyticsEntityRepository.save(mainAnalyticsEntityList);
		messageRepository.save(processedList);

	}

	public ArrayList<MessageEntity> getMessageEntity() {

		// MessageEntity messageEntity =
		// messageRepository.getByCustomerId("10002");
		// System.out.println(messageEntity.getEmailId());
		ArrayList<MessageEntity> messageEntityList = (ArrayList<MessageEntity>) messageRepository.findAll();

		return messageEntityList;
	}
}