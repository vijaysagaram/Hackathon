package com.hackathon.storage;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

@Transactional
public interface MainAnalyticsEntityRepository extends JpaRepository<MainAnalyticsEntity, Long> {
}